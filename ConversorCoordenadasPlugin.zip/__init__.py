# Inicialización del plugin Conversor de Coordenadas
