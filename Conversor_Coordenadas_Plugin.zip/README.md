# Conversor de Coordenadas - Plugin QGIS

Este plugin permite convertir coordenadas entre formatos DMS (grados, minutos, segundos) y decimales dentro de QGIS.

## Instalación

1. Copia la carpeta `ConversorCoordenadasPlugin` a la carpeta de plugins de QGIS:

   - Windows: `C:\Users\<usuario>\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\`
   - Linux: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`
   - MacOS: `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/`

2. Abre QGIS.
3. Ve a **Complementos > Administrar e Instalar Complementos**.
4. Busca el plugin **Conversor de Coordenadas** y actívalo.

## Uso

Haz clic en el botón de la barra de herramientas para abrir el conversor.

---

## Autor

Indira Sacaza  
tuemail@ejemplo.com
