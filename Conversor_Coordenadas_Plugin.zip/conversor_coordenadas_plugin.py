from PyQt5.QtCore import QCoreApplication
from PyQt5.QtWidgets import QAction, QMessageBox
from qgis.core import QgsProject

class ConversorCoordenadasPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.accion = None

    def initGui(self):
        self.accion = QAction("Conversor de Coordenadas", self.iface.mainWindow())
        self.accion.triggered.connect(self.ejecutar)
        self.iface.addToolBarIcon(self.accion)
        self.iface.addPluginToMenu("Conversor de Coordenadas", self.accion)

    def ejecutar(self):
        QMessageBox.information(None, "Conversor", "Aquí se ejecutaría el conversor de coordenadas.")

    def unload(self):
        self.iface.removeToolBarIcon(self.accion)
        self.iface.removePluginMenu("Conversor de Coordenadas", self.accion)
